package com.HospitalManagementSystem.controller;

import com.HospitalManagementSystem.entity.Doctor;
import com.HospitalManagementSystem.service.DoctorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/doctors")
public class DoctorController {

    @Autowired
    private DoctorService service;

    @PostMapping("/add")
    public void addDoctor(@RequestBody Doctor doctor) {
        service.addDoctor(doctor);
    }

    @GetMapping("/all")
    public List<Doctor> showAllDoctors() {
        return service.getAllDoctors();
    }
}
