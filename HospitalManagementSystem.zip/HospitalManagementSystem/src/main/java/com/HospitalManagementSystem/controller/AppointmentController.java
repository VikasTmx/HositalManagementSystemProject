package com.HospitalManagementSystem.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.HospitalManagementSystem.entity.Appointment;

import com.HospitalManagementSystem.service.AppointmentService;


@RestController
@RequestMapping("/appointment")

public class AppointmentController {
	@Autowired
	private AppointmentService service;
	@PostMapping
	public void addAppointment(@RequestBody Appointment appointment) {
		service.addAppointment(appointment);		
	}
@GetMapping("/all")	
public void showAllAppointment() {
	service.getAllAppointments().forEach(System.out::println);
}
}
