package com.HospitalManagementSystem.controller;

import com.HospitalManagementSystem.entity.Patient;
import com.HospitalManagementSystem.service.PatientService;
import java.util.List;

public class PatientController {
	private PatientService patientService = new PatientService();

    public void addPatient(Patient patient) {
        patientService.addPatient(patient);
    }

    public List<Patient> getAllPatients() {
        return patientService.getAllPatients();
    }
}
