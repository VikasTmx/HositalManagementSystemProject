package com.HospitalManagementSystem.service;

import com.HospitalManagementSystem.entity.Doctor;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service

public class DoctorService {
	 private List<Doctor> doctors = new ArrayList<>();

	    public void addDoctor(Doctor doctor) {
	        doctors.add(doctor);
	    }

	    public List<Doctor> getAllDoctors() {
	        return doctors;
	    }


}
